def add_one(n):
    return n + 1

def add_two(n):
    return n + 2
