# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['example_package']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'packaging-tutorial',
    'version': '0.2.0',
    'description': '',
    'long_description': None,
    'author': 'Gabriel Pedrosa',
    'author_email': 'gabriel@alude.com.br',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
